function input(value){
    document.getElementById('output').value += value;
}
function cal(){
    try{
        document.getElementById('output').value = eval(document.getElementById('output').value);
        }
        catch(error){
            document.getElementById('output').value ="Error";

        }
}
function c(){
    document.getElementById("output").value="";
}